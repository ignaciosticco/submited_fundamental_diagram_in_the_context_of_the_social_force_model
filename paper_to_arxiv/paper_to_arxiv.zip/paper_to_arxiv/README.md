# fundamental-diagram-in-the-contex-of-the-social-force-model
paper for publication
